import com.dao.*;
import com.bean.*;
import org.hibernate.*;
import org.hibernate.cfg.Configuration;
import org.hibernate.SessionFactory;



public class TestApplication {

	public static void main(String[] args) {
	Configuration cfg=new Configuration();
	SessionFactory s=cfg.configure("hibernate.cfg.xml").buildSessionFactory();
	Session sc=s.openSession();
	CustomerDAO c=new CustomerDAO();
	c.setSession(sc);
	Customer p=new Customer();
	p.setCustName("Peter");
	Address a=new Address();
	a.setDoorNo("D1"); a.setStreetName("MG Street"); a.setDistrict("BLR"); a.setPincode("666123");
	
	c.addCustomer(p,a);
	



	}

}
