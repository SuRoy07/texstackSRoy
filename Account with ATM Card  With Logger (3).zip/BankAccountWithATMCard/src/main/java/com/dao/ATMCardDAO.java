package com.dao;

import com.bean.ATMCard;
import com.bean.Account;
import com.repository.AccountRepository;
import com.repository.ATMCardRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

@Service
public class ATMCardDAO {
	
	private static final Logger logger=LoggerFactory.getLogger(AccountDAO.class);
	
	@Autowired
	private ATMCardRepository atmCardRepository;
	
	@Autowired
	private AccountRepository accountRepository;
	
	
	public void issueATMCardToAccount(int accountNumber, ATMCard atmCardObjet) {
			//fill code
			
		Account account = accountRepository.getById(accountNumber);
		atmCardObjet.setAccount(account);
		
		try{
		    atmCardRepository.save(atmCardObjet);
		    logger.info("ATM card successfully issued to account number{}", accountNumber);
		}
		catch(Exception e){
		    logger.info("ATM card not issued to account number{}", accountNumber);
		}
	}

}
