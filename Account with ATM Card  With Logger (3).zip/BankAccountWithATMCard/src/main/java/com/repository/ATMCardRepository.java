package com.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.bean.ATMCard;
import com.bean.*;
public interface ATMCardRepository extends JpaRepository<ATMCard,String> {

}
