package com.bean;
 
import javax.persistence.Column;
import javax.persistence.Embeddable;
 
@Embeddable
public class Address {
    @Column(name = "doorno")
    private String doorNo;
 
    @Column(name = "streetname")
    private String streetName;
 
    @Column(name = "district")
    private String district;
 
    @Column(name = "pincode")
    private String pincode;
 
    public String getDoorNo() {
        return doorNo;
    }
 
    public void setDoorNo(String doorNo) {
        this.doorNo = doorNo;
    }
 
    public String getStreetName() {
        return streetName;
    }
 
    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }
 
    public String getDistrict() {
        return district;
    }
 
    public void setDistrict(String district) {
        this.district = district;
    }
 
    public String getPincode() {
        return pincode;
    }
 
    public void setPincode(String pincode) {
        this.pincode = pincode;
    }
}