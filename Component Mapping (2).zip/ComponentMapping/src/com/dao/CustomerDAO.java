package com.dao;
 
import com.bean.Address;
import com.bean.Customer;
import org.hibernate.Session;
import org.hibernate.Transaction;
 
public class CustomerDAO {
    private Session session;
 
    public Session getSession() {
        return session;
    }
 
    public void setSession(Session session) {
        this.session = session;
    }
 
    public int addCustomer(Customer customer, Address address) {
        customer.setAddress(address);
        Transaction transaction = null;
        int customerId = 0;
        try {
            transaction = session.beginTransaction();
            session.save(customer);
            customerId = customer.getCustId();
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
        return customerId;
    }
}