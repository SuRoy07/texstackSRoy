package com.dao;

import com.bean.Account;
import com.bean.Transactions;
import com.repository.AccountRepository;
import com.repository.TransactionsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public class AccountDAO {
    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private TransactionsRepository transactionsRepository;

    public void addAccount(Account account) {
        accountRepository.save(account);
    }

    public void performTransactionOnAccount(int accountNumber, Transactions transaction) {
        Account account = accountRepository.findById(accountNumber)
                .orElseThrow(() -> new RuntimeException("Account not found"));
        transaction.setAccount(account);
        transactionsRepository.save(transaction);
        account.getTransactionList().add(transaction);
        accountRepository.save(account);
    }

    public List<Transactions> retrieveTransactionDetails(int accountNumber, LocalDate startDate, LocalDate endDate) {
        return transactionsRepository.findByAccount_AccountNumberAndTransactionDateBetween(accountNumber, startDate, endDate);
    }
}


