package com.dao;

import com.bean.ATMCard;
import com.bean.Account;
import com.repository.AccountRepository;
import com.repository.ATMCardRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

@Service
public class ATMCardDAO {
	
	private static final Logger logger = LoggerFactory.getLogger(AccountDAO.class);
	
	@Autowired
	private ATMCardRepository atmCardRepository;
	
	@Autowired
	private AccountRepository accountRepository;
	
	public void issueATMCardToAccount(int accountNumber, ATMCard atmCardObject) {
	    Account account = accountRepository.getById(accountNumber);
	    atmCardObject.setAccount(account);
	    
	    try{
	        atmCardRepository.save(atmCardObject);
	        logger.info("ATM card successfully issued to account number {}", accountNumber);
	    }catch(Exception e){
	        logger.info("ATM card not issued to account number {}", accountNumber);
	    }
			//fill code
	}

}
