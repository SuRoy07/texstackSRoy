package com.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.bean.ATMCard;
import java.util.*;
import org.springframework.stereotype.Repository;
@Repository

public interface ATMCardRepository extends JpaRepository<ATMCard,Integer> {

}
