package com.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.jpa.repository.Query;

import java.util.List;

import java.time.LocalDate;

import org.springframework.data.repository.query.Param;

import com.bean.Transactions;
 
 
public interface TransactionsRepository extends JpaRepository<Transactions, Integer> {
 
    @Query("SELECT t FROM Transactions t WHERE t.account.accountNumber = :accountNumber AND t.transactionDate BETWEEN :startDate AND :endDate")

    List<Transactions> retrieveTransactionDetails(@Param("accountNumber") int accountNumber, @Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);

}

 