package com.dao;

import com.repository.AccountRepository;

import com.repository.TransactionsRepository;

import java.time.LocalDate;
 
import java.util.List;
 
import org.springframework.stereotype.Repository;

import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
 
import java.util.List;

import java.util.Optional;

import com.bean.Account;

import com.bean.Transactions;
 
@Repository

public class AccountDAO {
 
//Fill the code

    @Autowired

    private AccountRepository accountRepository;

    @Autowired

    private TransactionsRepository transactionsRepository;

	public void addAccount(Account account) {

	    accountRepository.save(account);

	}

	public void performTransactionOnAccount(int accountNumber, Transactions transaction)

	{

	    Optional<Account> optionalAccount = accountRepository.findById(accountNumber);

    if (optionalAccount.isPresent()) {

        Account account = optionalAccount.get();

        List<Transactions> transactionsList=account.getTransactionList();

        if(transactionsList==null){

            transactionsList=new ArrayList<>();

        }

        transaction.setAccount(account);

        transactionsRepository.save(transaction);

        transactionsList.add(transaction);

        account.setTransactionList(transactionsList);

        accountRepository.save(account);

	}

	else {

        System.out.println("Account Number " + accountNumber + " not found.");

    }

	}
 
    public List<Transactions> retrieveTransactionDetails(int accountNumber, LocalDate startDate, LocalDate endDate) {

        return transactionsRepository.retrieveTransactionDetails(accountNumber, startDate, endDate);

}
 
 
}

 