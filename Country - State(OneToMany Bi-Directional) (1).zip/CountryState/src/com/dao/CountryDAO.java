package com.dao;

import java.util.List;

import org.hibernate.Session;
 
import org.hibernate.Transaction;

import com.bean.Country;
 
import com.bean.State;
 
import org.hibernate.Query;


public class CountryDAO {

    private Session session;
 
	public Session getSession() {
 
		return session;
 
	}

	public void setSession(Session session) {
 
		this.session = session;
 
	}

	public void addCountry(Country country)
 
	{
 
	    Transaction transaction = session.beginTransaction();
 
	    session.save(country);
 
	    transaction.commit();
 
	}	
 
	public void addStatetoCountry(String countryName, State state)
 
	{	 	  	    	
 
	    Transaction transaction = session.beginTransaction();
 
	    Country country=(Country)session.get(Country.class,countryName);
 
        state.setCountry(country);
 
	    session.save(state);
 
	    transaction.commit();
 
	}
 
	public List<State> stateWithMaxPopulation(String countryName)
 
	{
 
	     Query query = session.createQuery("FROM State WHERE country.countryName = :countryName AND population = (SELECT MAX(population) FROM State WHERE country.countryName = :countryName)");
 
         query.setParameter("countryName", countryName);
 
         return query.list();
 
	}
 
	public void removeCountry(String countryName)
 
	{
 
	    Transaction transaction = session.beginTransaction();
 
	    Country country=(Country)session.get(Country.class,countryName);
 
	    session.delete(country);
 
	    transaction.commit();
 
	}
 
}
 
 