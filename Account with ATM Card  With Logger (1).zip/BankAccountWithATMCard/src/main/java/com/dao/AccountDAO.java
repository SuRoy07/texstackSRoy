package com.dao;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.beans.factory.annotation.Autowired;
import com.repository.AccountRepository;
import com.repository.ATMCardRepository;
import com.bean.Account;


@Repository
public class AccountDAO {
	
	public static final Logger logger=LoggerFactory.getLogger(AccountDAO.class);
	
	@Autowired
	private AccountRepository acr;
	
	
	@Autowired
	private ATMCardRepository atmr;
	
	
	public void openAccount(Account account) {
		//fill code
		acr.save(account);
		logger.info("Account with id{} added successfully",account.getAccountNumber());
	}
	
	public List<Account> retrieveAccountBasedOnCardType(String cardType){
		//fill code
		
		List<Account> accounts =acr.findByAtmCardCardType(cardType);
		if(accounts.isEmpty())
	
		{
		    logger.error("No account with this card type {}",cardType);
		}
		else
		{
		    		    logger.error("Account details with card type {} retrieved successfully",cardType);

		}
		return accounts;
		
	}
}
