package com.dao;

import com.bean.ATMCard;
import com.bean.Account;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import com.repository.AccountRepository;
import com.repository.ATMCardRepository;

@Service
public class ATMCardDAO {
	
	private static final Logger logger=LoggerFactory.getLogger(AccountDAO.class);
	@Autowired
	private AccountRepository acr;
	@Autowired
	private ATMCardRepository atmr;
	
	public void issueATMCardToAccount(int accountNumber, ATMCard atmCardObjet) {
			//fill code
			Account account =acr.getById(accountNumber);
			atmCardObjet.setAccount(account);
			try {
          atmr.save(atmCardObjet);
          logger.info("ATM card successfully issued to account number {}",accountNumber);
			} 
			catch(Exception e)
			{
			              logger.info("ATM card not issued to account number {}",accountNumber);

			    
			}
			

}}
